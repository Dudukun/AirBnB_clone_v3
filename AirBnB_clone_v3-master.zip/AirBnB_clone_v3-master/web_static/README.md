# 0x01. AirBnB clone - Web static
At the end of this project you are expected to be able to explain to anyone, without the help of Google:
* What is HTML?
* How do you create an HTML page?
* What is a markup language?
* What is the DOM?
* What is an element / tag?
* What is an attribute?
* How does the browser load a webpage?
* What is CSS?
* How do you add style to an element?
* What is a class?
* What is a selector?
* How do you compute CSS Specificity Value?
* What are Box properties in CSS?
